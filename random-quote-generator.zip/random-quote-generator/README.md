# 🧠 Random Quote Generator

A simple JavaScript web app that displays random motivational quotes.

## 💡 Features
- Shows a new quote every time you click the button
- Built with HTML, CSS, and JavaScript
- Clean and responsive design

## 🚀 Demo
[Live Demo](https://your-demo-link.com)

## 📸 Screenshot
*(Add your screenshot.png here)*

## 🛠️ How to Use
1. Clone the repo:
   ```
   git clone https://github.com/yourusername/random-quote-generator.git
   ```
2. Open `index.html` in your browser.

## 📄 License
MIT
